<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require 'db.php';
require 'audit.php'; // файл с функцией log_action()

// Массив перевода названий колонок на русский
$column_ru = [
    'id'            => 'ID',
    'name'          => 'Название',
    'type'          => 'Тип',
    'address'       => 'Адрес',
    'status'        => 'Статус',
    'responsible'   => 'Ответственный',
    'created_at'    => 'Дата создания',
    'login'         => 'Логин',
    'password'      => 'Пароль',
    'full_name'     => 'Полное имя',
    'role'          => 'Роль',
    'object_id'     => 'Объект',
    'work_type'     => 'Тип работ',
    'planned_start' => 'План. начало',
    'planned_end'   => 'План. окончание',
    'description'   => 'Описание',
    'plan_id'       => 'План работ',
    'date_performed'=> 'Дата выполнения',
    'result'        => 'Результат',
    'file_name'     => 'Файл',
    'file_path'     => 'Путь к файлу',
    'overdue_reason'=> 'Причина просрочки', // новая колонка
];

// Подсчёт непрочитанных сообщений для текущего пользователя
$unread_count = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
    $stmt->execute([$_SESSION['user_id']]);
    $unread_count = $stmt->fetchColumn();
}

// Выход
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    // Логируем выход
    if (isset($_SESSION['user_id'])) {
        log_action('LOGOUT', 'users', $_SESSION['user_id']);
    }
    session_destroy();
    header("Location: index.php");
    exit;
}

// Обработка входа
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_login'])) {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && $user['password'] === $password) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'] ?? $user['login'];
        $_SESSION['role'] = $user['role'] ?? 'исполнитель';
        $_SESSION['login'] = $user['login'];
        // Логируем вход
        log_action('LOGIN', 'users', $user['id']);
        header("Location: dashboard.php");
        exit;
    }
    $login_error = "Неверный логин или пароль";
}

// Если не авторизован – показываем форму входа
if (!isset($_SESSION['user_id'])) {
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Вход в систему планирования работ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .password-toggle {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
        .password-toggle:hover {
            color: #2ecc71;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container fade-in">
        <div class="login-card">
            <div class="login-header">
                <h1>🏙️ Система планирования благоустройства</h1>
                <p>г. Белово, Кемеровская область</p>
            </div>
            <?php if($login_error): ?>
                <div class="alert alert-danger"><?= $login_error ?></div>
            <?php endif; ?>
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label>Логин</label>
                    <input type="text" name="login" class="form-control" required>
                </div>
                <div class="form-group position-relative">
                    <label>Пароль</label>
                    <input type="password" name="password" class="form-control" id="passwordInput" required>
                    <span class="password-toggle" onclick="togglePassword()">
                        <i class="fas fa-eye" id="togglePasswordIcon"></i>
                    </span>
                </div>
                <button type="submit" name="do_login" class="login-btn">Войти</button>
            </form>
            <div class="login-footer">© <?= date('Y') ?> "Управление" УЖКиДК УБГО</div>
        </div>
    </div>
    <script>
        function togglePassword() {
            const input = document.getElementById('passwordInput');
            const icon = document.getElementById('togglePasswordIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
<?php
    exit;
}

// --- Ролевой доступ ---
$user_role = $_SESSION['role'] ?? 'исполнитель';

$all_tables = [
    'objects'        => 'Объекты благоустройства',
    'work_plans'     => 'Планы работ',
    'work_executions'=> 'Выполнение работ',
    'users'          => 'Пользователи'
];

if ($user_role == 'администратор') {
    $tables = $all_tables;
} elseif ($user_role == 'планировщик') {
    $tables = [
        'work_plans'     => 'Планы работ',
        'work_executions'=> 'Выполнение работ'
    ];
} else { // исполнитель
    $tables = [
        'objects'        => 'Объекты благоустройства',
        'work_plans'     => 'Планы работ',
        'work_executions'=> 'Выполнение работ'
    ];
}

$current_table = isset($_GET['table']) && array_key_exists($_GET['table'], $tables) ? $_GET['table'] : array_key_first($tables);

// Проверка прав на запись/удаление
function can_write($table, $role) {
    if ($role == 'администратор') return true;
    if ($role == 'планировщик' && in_array($table, ['work_plans', 'work_executions'])) return true;
    if ($role == 'исполнитель' && in_array($table, ['work_executions', 'objects'])) return true;
    return false;
}
function can_delete($table, $role) {
    if ($role == 'администратор') return true;
    if ($role == 'планировщик' && in_array($table, ['work_plans', 'work_executions'])) return true;
    if ($role == 'исполнитель' && in_array($table, ['work_executions', 'objects'])) return true;
    return false;
}

// --- Сохранение причины просрочки (НОВОЕ) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_overdue_reason'])) {
    $plan_id = (int)$_POST['plan_id'];
    $reason = trim($_POST['overdue_reason']);
    $other_text = trim($_POST['other_reason'] ?? '');
    
    if ($reason === 'other' && !empty($other_text)) {
        $reason = $other_text;
    }
    
    if ($plan_id && !empty($reason)) {
        try {
            $stmt = $pdo->prepare("UPDATE work_plans SET overdue_reason = ? WHERE id = ?");
            $stmt->execute([$reason, $plan_id]);
            log_action('UPDATE_REASON', 'work_plans', $plan_id, null, ['overdue_reason' => $reason]);
        } catch (PDOException $e) {
            log_action('ERROR', null, null, ['message' => $e->getMessage()], null);
        }
    }
    header("Location: index.php?table=work_plans");
    exit;
}

// Удаление записи
if (isset($_GET['delete_id'])) {
    if (!can_delete($current_table, $user_role)) {
        die('Нет прав на удаление');
    }
    $id = $_GET['delete_id'];
    try {
        // Получаем старые данные для лога
        $stmt = $pdo->prepare("SELECT * FROM $current_table WHERE id = ?");
        $stmt->execute([$id]);
        $old_row = $stmt->fetch();
        
        // Удаление файла, если есть
        if (isset($old_row['file_path']) && $old_row['file_path'] && file_exists($old_row['file_path'])) {
            unlink($old_row['file_path']);
        }
        
        $stmt = $pdo->prepare("DELETE FROM $current_table WHERE id = ?");
        $stmt->execute([$id]);
        
        log_action('DELETE', $current_table, $id, $old_row, null);
        
        header("Location: index.php?table=$current_table&msg=deleted");
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка удаления: " . $e->getMessage();
        log_action('ERROR', $current_table, $id, ['error' => $e->getMessage()], null);
    }
}

// Сохранение (добавление/редактирование)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_record'])) {
    if (!can_write($current_table, $user_role)) {
        die('Нет прав на запись');
    }

    $id = $_POST['id'] ?? null;
    $columns = $_POST['columns'] ?? [];
    $delete_attachment = isset($_POST['delete_attachment']);
    $uploaded_file = $_FILES['attachment'] ?? null;

    $old_row = null;
    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM $current_table WHERE id = ?");
        $stmt->execute([$id]);
        $old_row = $stmt->fetch();
    }

    // Обработка файла (как в оригинале)
    if ($uploaded_file && $uploaded_file['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $original_name = basename($uploaded_file['name']);
        $extension = pathinfo($original_name, PATHINFO_EXTENSION);
        $new_filename = uniqid() . '_' . time() . '.' . $extension;
        $destination = $upload_dir . $new_filename;
        if (move_uploaded_file($uploaded_file['tmp_name'], $destination)) {
            if ($old_row && !empty($old_row['file_path']) && file_exists($old_row['file_path'])) {
                unlink($old_row['file_path']);
            }
            $columns['file_name'] = $original_name;
            $columns['file_path'] = $destination;
        }
    } elseif ($delete_attachment && $old_row && !empty($old_row['file_path'])) {
        if (file_exists($old_row['file_path'])) {
            unlink($old_row['file_path']);
        }
        $columns['file_name'] = null;
        $columns['file_path'] = null;
    }

    $values = [];
    $fields = [];
    $placeholders = [];
    foreach ($columns as $col => $val) {
        if (in_array($col, ['object_id', 'plan_id']) && $val === '') {
            continue;
        }
        $fields[] = "$col = ?";
        $placeholders[] = "?";
        $values[] = $val;
    }

    try {
        if (!empty($id)) {
            $sql = "UPDATE $current_table SET " . implode(', ', $fields) . " WHERE id = ?";
            $values[] = $id;
            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            log_action('UPDATE', $current_table, $id, $old_row, $columns);
        } else {
            $cols_str = implode(', ', array_keys($columns));
            $vals_str = implode(', ', $placeholders);
            $sql = "INSERT INTO $current_table ($cols_str) VALUES ($vals_str)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            $new_id = $pdo->lastInsertId();
            log_action('CREATE', $current_table, $new_id, null, $columns);
        }
        header("Location: index.php?table=$current_table&msg=saved");
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка сохранения: " . $e->getMessage();
        log_action('ERROR', $current_table, $id ?? null, ['error' => $e->getMessage()], $columns);
    }
}

// Получение данных текущей таблицы
try {
    switch ($current_table) {
        case 'work_plans':
            $sql = "SELECT p.*, o.name as object_name 
                    FROM work_plans p 
                    LEFT JOIN objects o ON p.object_id = o.id 
                    ORDER BY p.planned_start DESC";
            break;
        case 'work_executions':
            $sql = "SELECT e.*, o.name as object_name, p.work_type as plan_work_type
                    FROM work_executions e 
                    LEFT JOIN objects o ON e.object_id = o.id 
                    LEFT JOIN work_plans p ON e.plan_id = p.id 
                    ORDER BY e.date_performed DESC";
            break;
        default:
            $sql = "SELECT * FROM $current_table ORDER BY id DESC";
    }
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Ошибка загрузки данных: " . $e->getMessage();
    log_action('ERROR', $current_table, null, ['error' => $e->getMessage()], null);
    $rows = [];
}

// Списки для выпадающих полей
$objects_list = [];
if (in_array($current_table, ['work_plans', 'work_executions'])) {
    $stmt = $pdo->query("SELECT id, name, address FROM objects ORDER BY name");
    $objects_list = $stmt->fetchAll();
}
$plans_list = [];
if ($current_table == 'work_executions') {
    $stmt = $pdo->query("SELECT id, object_id, work_type, planned_start FROM work_plans ORDER BY planned_start DESC");
    $plans_list = $stmt->fetchAll();
}

if (count($rows) > 0) {
    $columns_info = array_keys($rows[0]);
} else {
    try {
        $q = $pdo->prepare("DESCRIBE $current_table");
        $q->execute();
        $columns_info = $q->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        $error = "Ошибка получения структуры таблицы: " . $e->getMessage();
        log_action('ERROR', $current_table, null, ['error' => $e->getMessage()], null);
        $columns_info = [];
    }
}
$display_columns = array_filter($columns_info, fn($col) => !in_array($col, ['file_name', 'file_path', 'overdue_reason'])); // overdue_reason не выводим в обычных колонках, выведем отдельно

$edit_row = null;
if (isset($_GET['edit_id']) && can_write($current_table, $user_role)) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM $current_table WHERE id = ?");
        $stmt->execute([$_GET['edit_id']]);
        $edit_row = $stmt->fetch();
    } catch (PDOException $e) {
        $error = "Ошибка загрузки записи: " . $e->getMessage();
        log_action('ERROR', $current_table, $_GET['edit_id'], ['error' => $e->getMessage()], null);
    }
}

$overdue_plans = [];
try {
    $stmt = $pdo->query("
        SELECT p.*, o.name as object_name 
        FROM work_plans p
        LEFT JOIN objects o ON p.object_id = o.id
        WHERE p.planned_end < CURDATE() AND p.status NOT IN ('выполнено', 'отменено')
        ORDER BY p.planned_end ASC
    ");
    $overdue_plans = $stmt->fetchAll();
} catch (PDOException $e) {}

$user_display_name = $_SESSION['full_name'] ?? $_SESSION['login'] ?? 'Пользователь';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Система планирования благоустройства</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="admin-panel">
    <button class="mobile-toggle d-lg-none">
        <i class="fas fa-bars"></i>
    </button>

    <nav class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo"><i class="fas fa-tree"></i></div>
            <div class="sidebar-title">BlagoBelovo</div>
        </div>
        <ul class="sidebar-nav">
            <?php foreach ($tables as $tbl => $name): ?>
            <li class="nav-item">
                <a href="?table=<?= $tbl ?>" class="nav-link <?= $current_table == $tbl ? 'active' : '' ?>">
                    <i class="nav-icon fas fa-<?= 
                        $tbl == 'objects' ? 'city' : 
                        ($tbl == 'work_plans' ? 'calendar-alt' : 
                        ($tbl == 'work_executions' ? 'clipboard-check' : 
                        ($tbl == 'users' ? 'users' : 'table'))) ?>"></i>
                    <span><?= $name ?></span>
                </a>
            </li>
            <?php endforeach; ?>
            <li class="nav-item">
                <a href="reports.php" class="nav-link">
                    <i class="nav-icon fas fa-chart-bar"></i><span>Отчеты</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="nav-icon fas fa-tachometer-alt"></i><span>Дашборд</span>
                </a>
            </li>
            <!-- Пункт меню: Сообщения -->
            <li class="nav-item">
                <a href="chat.php" class="nav-link">
                    <i class="nav-icon fas fa-comments"></i>
                    <span>Сообщения</span>
                    <?php if ($_SESSION['role'] == 'администратор'): ?><li class="nav-item"><a href="backup.php" class="nav-link"><i class="nav-icon fas fa-database"></i><span>Бэкап</span></a></li>
                    <?php endif; ?>
                    <?php if ($unread_count > 0): ?>
                        <span class="badge bg-danger ms-2"><?= $unread_count ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <!-- Для администратора ссылка на аудит (НОВОЕ) -->
            <?php if ($_SESSION['role'] == 'администратор'): ?>
            <li class="nav-item">
                <a href="audit.php" class="nav-link">
                    <i class="nav-icon fas fa-history"></i><span>Журнал аудита</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><?= mb_substr($user_display_name, 0, 1, 'UTF-8') ?></div>
                <div class="user-details">
                    <h4><?= htmlspecialchars($user_display_name) ?></h4>
                    <p><?= htmlspecialchars($_SESSION['role'] ?? 'Пользователь') ?></p>
                </div>
            </div>
            <a href="?action=logout" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i><span>Выйти</span>
            </a>
        </div>
    </nav>

    <main class="main-content">
        <div class="content-header fade-in">
            <div class="header-title">
                <h1><?= $tables[$current_table] ?></h1>
                <p>Управление данными по благоустройству г. Белово</p>
            </div>
            <div class="header-actions">
                <?php 
                $show_add_button = (
                    $user_role == 'администратор' ||
                    ($user_role == 'планировщик' && in_array($current_table, ['work_plans', 'work_executions'])) ||
                    ($user_role == 'исполнитель' && in_array($current_table, ['work_executions', 'objects']))
                );
                if ($show_add_button): 
                ?>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editModal" onclick="clearForm()">
                    <i class="fas fa-plus"></i> Добавить запись
                </button>
                <?php endif; ?>
                <?php if(count($overdue_plans) > 0): ?>
                <button class="btn btn-danger ms-2" data-bs-toggle="modal" data-bs-target="#overdueModal">
                    <i class="fas fa-exclamation-triangle"></i> Просрочено: <?= count($overdue_plans) ?>
                </button>
                <?php endif; ?>
            </div>
        </div>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger fade-in"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if(isset($_GET['msg'])): ?>
            <?php if($_GET['msg'] == 'saved'): ?>
                <div class="alert alert-success fade-in">✅ Данные сохранены!</div>
            <?php elseif($_GET['msg'] == 'deleted'): ?>
                <div class="alert alert-warning fade-in">🗑️ Запись удалена!</div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Статистика для объектов -->
        <?php if($current_table == 'objects'): ?>
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Всего объектов</h5>
                        <p class="card-text display-6"><?= count($rows) ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Активны</h5>
                        <?php 
                        $active = array_filter($rows, fn($item) => $item['status'] == 'активен');
                        ?>
                        <p class="card-text display-6"><?= count($active) ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h5 class="card-title">На реконструкции</h5>
                        <?php 
                        $reconstr = array_filter($rows, fn($item) => $item['status'] == 'на реконструкции');
                        ?>
                        <p class="card-text display-6"><?= count($reconstr) ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h5 class="card-title">Просроченные планы</h5>
                        <p class="card-text display-6"><?= count($overdue_plans) ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Таблица данных -->
        <div class="table-container fade-in">
            <div class="table-header">
                <div class="table-title">Записи таблицы</div>
                <div class="table-count">
                    <span class="badge bg-primary"><?= count($rows) ?> записей</span>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <?php foreach ($display_columns as $col): ?>
                                <th><?= htmlspecialchars($column_ru[$col] ?? $col) ?></th>
                            <?php endforeach; ?>
                            
                            <!-- НОВАЯ КОЛОНКА: Причина просрочки (только для work_plans) -->
                            <?php if ($current_table == 'work_plans'): ?>
                                <th><?= htmlspecialchars($column_ru['overdue_reason'] ?? 'Причина просрочки') ?></th>
                            <?php endif; ?>
                            
                            <?php if (in_array($current_table, ['work_plans', 'work_executions'])): ?>
                                <th>Файл</th>
                            <?php endif; ?>
                            
                            <?php 
                            $show_actions = ($current_table != 'users') && (
                                $user_role == 'администратор' || 
                                ($user_role == 'планировщик' && in_array($current_table, ['work_plans', 'work_executions'])) ||
                                ($user_role == 'исполнитель' && in_array($current_table, ['work_executions', 'objects']))
                            );
                            if ($show_actions): 
                            ?>
                                <th>Действия</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($rows) > 0): ?>
                            <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($display_columns as $col): ?>
                                    <td class="table-cell">
                                        <?php if($col == 'object_id' && in_array($current_table, ['work_plans', 'work_executions'])): ?>
                                            <?= htmlspecialchars($row['object_name'] ?? 'Неизвестно') ?>
                                        <?php elseif($col == 'plan_id' && $current_table == 'work_executions'): ?>
                                            <?php if(!empty($row['plan_id'])): ?>
                                                <a href="?table=work_plans&edit_id=<?= $row['plan_id'] ?>">План #<?= $row['plan_id'] ?></a>
                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        <?php elseif($col == 'status'): ?>
                                            <span class="badge bg-<?= 
                                                $row[$col] == 'активен' || $row[$col] == 'выполнено' ? 'success' : 
                                                ($row[$col] == 'просрочено' ? 'danger' : 
                                                ($row[$col] == 'в работе' ? 'warning' : 'secondary')) ?>">
                                                <?= htmlspecialchars($row[$col]) ?>
                                            </span>
                                        <?php elseif($col == 'result'): ?>
                                            <span class="badge bg-<?= $row[$col] == 'выполнено' ? 'success' : 'danger' ?>">
                                                <?= htmlspecialchars($row[$col]) ?>
                                            </span>
                                        <?php elseif(in_array($col, ['planned_start', 'planned_end', 'date_performed', 'created_at']) && !empty($row[$col])): ?>
                                            <?php 
                                            $date = new DateTime($row[$col]);
                                            $now = new DateTime();
                                            $interval = $now->diff($date);
                                            $days = (int)$interval->format('%R%a');
                                            $class = '';
                                            if ($col == 'planned_end' && $row['status'] != 'выполнено') {
                                                if ($days < 0) $class = 'bg-danger text-white';
                                                elseif ($days <= 7) $class = 'bg-warning';
                                            }
                                            ?>
                                            <span class="badge <?= $class ?>">
                                                <?= htmlspecialchars($row[$col]) ?>
                                                <?php if($col == 'planned_end' && $row['status'] != 'выполнено'): ?>
                                                    <br><small><?= $days > 0 ? "через $days дн." : "просрочено " . abs($days) . " дн." ?></small>
                                                <?php endif; ?>
                                            </span>
                                        <?php elseif($col == 'password'): ?>
                                            ••••••••
                                        <?php else: ?>
                                            <?= htmlspecialchars($row[$col] ?? '') ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>

                                <!-- НОВАЯ КОЛОНКА: Причина просрочки (для work_plans) -->
                                <?php if ($current_table == 'work_plans'): ?>
                                    <td>
                                        <?php 
                                        $reason = $row['overdue_reason'] ?? '';
                                        $can_edit_reason = (
                                            $user_role == 'исполнитель' &&
                                            $row['status'] == 'просрочено' &&
                                            !empty($row['responsible']) &&
                                            $row['responsible'] == $user_display_name
                                        );
                                        if ($can_edit_reason) {
                                            // Исполнитель может редактировать
                                            if (empty($reason)) {
                                                echo '<button class="btn btn-sm btn-warning" onclick="openReasonModal(' . $row['id'] . ', \'\')">Указать причину</button>';
                                            } else {
                                                echo htmlspecialchars($reason) . ' <button class="btn btn-sm btn-outline-warning" onclick="openReasonModal(' . $row['id'] . ', \'' . addslashes($reason) . '\')" title="Изменить"><i class="fas fa-pen"></i></button>';
                                            }
                                        } else {
                                            // Для всех остальных просто текст
                                            echo htmlspecialchars($reason ?: '—');
                                        }
                                        ?>
                                    </td>
                                <?php endif; ?>

                                <!-- Колонка с файлом -->
                                <?php if (in_array($current_table, ['work_plans', 'work_executions'])): ?>
                                    <td>
                                        <?php if (!empty($row['file_path']) && file_exists($row['file_path'])): ?>
                                            <a href="<?= htmlspecialchars($row['file_path']) ?>" target="_blank" title="Открыть в браузере" class="me-2">
                                                <i class="fas fa-eye text-primary"></i>
                                            </a>
                                            <a href="<?= htmlspecialchars($row['file_path']) ?>" download="<?= htmlspecialchars($row['file_name']) ?>" title="Скачать файл">
                                                <i class="fas fa-download text-success"></i>
                                            </a>
                                            <span class="ms-2 small"><?= htmlspecialchars($row['file_name']) ?></span>
                                        <?php elseif (!empty($row['file_name'])): ?>
                                            <span class="text-muted" title="Файл отсутствует на сервере">
                                                <i class="fas fa-exclamation-triangle text-warning me-1"></i><?= htmlspecialchars($row['file_name']) ?> (не найден)
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>

                                <!-- Действия -->
                                <?php if ($show_actions): ?>
                                    <td class="action-cell">
                                        <div class="action-buttons">
                                            <a href="?table=<?= $current_table ?>&edit_id=<?= $row['id'] ?>" 
                                               class="btn-icon btn-primary" title="Редактировать">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="?table=<?= $current_table ?>&delete_id=<?= $row['id'] ?>" 
                                               class="btn-icon btn-danger" 
                                               onclick="return confirm('Удалить запись?')" title="Удалить">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="100%" class="no-data text-center py-5">
                                    <i class="fas fa-database fa-3x mb-3 text-muted"></i>
                                    <p class="text-muted">Нет записей</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Модальное окно редактирования -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <!-- ... (без изменений, как в оригинале) ... -->
        <div class="modal-dialog modal-lg">
            <form method="POST" class="modal-content" enctype="multipart/form-data">
                <!-- содержимое модалки оставлено без изменений, но можно при необходимости добавить поле overdue_reason, если нужно редактировать админу. Пока не добавляем. -->
            </form>
        </div>
    </div>

    <!-- Модальное окно просроченных планов -->
    <?php if(count($overdue_plans) > 0): ?>
    <div class="modal fade" id="overdueModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title">Просроченные планы работ</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Обнаружены планы с истекшим сроком выполнения
                    </div>
                    <div class="list-group">
                        <?php foreach ($overdue_plans as $plan): ?>
                        <div class="list-group-item list-group-item-danger">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?= htmlspecialchars($plan['object_name']) ?></h6>
                                <small>ПРОСРОЧЕНО</small>
                            </div>
                            <p class="mb-1">
                                <?= htmlspecialchars($plan['work_type']) ?><br>
                                Срок: <?= htmlspecialchars($plan['planned_end']) ?>
                            </p>
                            <small>Ответственный: <?= htmlspecialchars($plan['responsible'] ?? '—') ?></small>
                            <?php if (!empty($plan['overdue_reason'])): ?>
                                <br><small>Причина: <?= htmlspecialchars($plan['overdue_reason']) ?></small>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                    <a href="?table=work_plans" class="btn btn-primary">Перейти к планам</a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- НОВОЕ МОДАЛЬНОЕ ОКНО: Причина просрочки -->
    <div class="modal fade" id="reasonModal" tabindex="-1">
        <div class="modal-dialog">
            <form method="POST" class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Укажите причину просрочки</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="plan_id" id="reasonPlanId">
                    <div class="mb-3">
                        <label class="form-label">Выберите причину:</label>
                        <select name="overdue_reason" class="form-select" id="reasonSelect" onchange="toggleOtherReason()">
                            <option value="Не успеваю по срокам">Не успеваю по срокам</option>
                            <option value="Были более важные планы">Были более важные планы</option>
                            <option value="Отсутствие материалов/техники">Отсутствие материалов/техники</option>
                            <option value="Погодные условия">Погодные условия</option>
                            <option value="other">Другая причина...</option>
                        </select>
                    </div>
                    <div class="mb-3" id="otherReasonBlock" style="display: none;">
                        <label class="form-label">Опишите причину:</label>
                        <textarea name="other_reason" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" name="save_overdue_reason" class="btn btn-primary">Сохранить</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelector('.mobile-toggle')?.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        <?php if (isset($edit_row) && !empty($edit_row)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            new bootstrap.Modal(document.getElementById('editModal')).show();
        });
        <?php endif; ?>

        function clearForm() {
            document.querySelector('#editModal input[name="id"]').value = '';
            document.querySelectorAll('#editModal input, #editModal textarea, #editModal select').forEach(el => {
                if (el.type !== 'hidden' && el.name !== 'save_record' && el.name !== 'attachment' && el.type !== 'file') {
                    if (el.type === 'select-one') el.selectedIndex = 0;
                    else el.value = '';
                }
            });
            document.querySelector('#editModal input[type="file"]').value = '';
            const fileBlock = document.querySelector('#editModal .mt-2');
            if (fileBlock) fileBlock.style.display = 'none';
        }

        // Функции для модалки причины
        function openReasonModal(planId, currentReason) {
            document.getElementById('reasonPlanId').value = planId;
            var select = document.getElementById('reasonSelect');
            var otherBlock = document.getElementById('otherReasonBlock');
            var otherTextarea = document.querySelector('textarea[name="other_reason"]');
            
            // Сброс
            select.value = 'Не успеваю по срокам';
            otherBlock.style.display = 'none';
            otherTextarea.value = '';
            
            // Если есть текущая причина, пытаемся выбрать соответствующий пункт или "другая"
            if (currentReason) {
                var found = false;
                for (var i = 0; i < select.options.length; i++) {
                    if (select.options[i].value === currentReason) {
                        select.selectedIndex = i;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    select.value = 'other';
                    otherTextarea.value = currentReason;
                    otherBlock.style.display = 'block';
                }
            }
            
            new bootstrap.Modal(document.getElementById('reasonModal')).show();
        }

        function toggleOtherReason() {
            var select = document.getElementById('reasonSelect');
            var otherBlock = document.getElementById('otherReasonBlock');
            otherBlock.style.display = select.value === 'other' ? 'block' : 'none';
        }
    </script>
</body>
</html>